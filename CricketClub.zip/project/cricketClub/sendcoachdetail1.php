<html>
    <head>
        <style>
            #ok{
                background-color: #e0b826;
                width:200px;
                padding: 10px;
                border-radius:10px;
                font-weight:bold;
            }
            #item{
                font-family: Roboto, Arial, sans-serif;
                font-size: 20px;
                font-weight: 400;
                text-align: center;
                border:1px solid black;
                width:500px;
                margin-left:450px;
                background-color: rgba(59, 58, 58, 0.549);
                border-radius:10px;
                padding: 50px;

            }
        </style>
    </head>
    <body>
<?php
$con = new mysqli("localhost","root","","cricket");

if(!$con)
{
    echo "Can't connect the the database";
}


$searchID=$_POST['searchID'];

 if(isset($_POST["btnClear"])){
    
    $sql="DELETE FROM `coach` WHERE `C_ID`='$searchID'";

    if(mysqli_query($con,$sql)){
        echo "<script type='text/javascript'>alert('Record has been Deletd succeefully');
        window.location='coachDetails.php';
        </script>";

    }else{
        echo "<script type='text/javascript'>alert('No search results for that ID,Please try again...!');
        window.location='coachDetails.php';
        </script>";
    }
    mysqli_close($con);
}
else if (isset($_POST['btnView'])) {
   
    $sql="SELECT `C_ID`, `C_Name`, `C_DOB`, `C_Address`, `C_NIC` FROM `coach` WHERE `C_ID`='$searchID'";
    $result=mysqli_query($con,$sql);

    

    if(mysqli_query($con,$sql)){
        while ($row = mysqli_fetch_assoc($result)) {
            echo"<div id='item'>";
            echo "Coach ID:";
            echo $row["C_ID"];
            echo "<br><br>Coach Name:";
            echo $row["C_Name"];
            echo "<br><br>Date of birth:";
            echo $row["C_DOB"];
            echo "<br><br>Address:";
            echo $row["C_Address"];
            echo "<br><br>NIC number:";
            echo $row["C_NIC"];
            echo "<br><br><a href='coachDetails.php'> <button id='ok' type='submit' name='btnView'>OK</button></a>";
            echo"</div>";
        }

    }else{
        echo "<script type='text/javascript'>alert('No search results for that ID,Please try again...!');
        window.location='inventory.php';
        </script>";
    }
    mysqli_close($con);;
}
?>
   </body>
</html>