<!doctype html>
<html lang="en">
    
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,height=device-height,initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
        <title>Cricket Club</title>
        <!-- Reset CSS -->
        <link href="css/reset.css" rel="stylesheet" type="text/css">
        <!-- Bootstrap -->
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <!-- Font Awesome -->
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!-- Iconmoon -->
        <link href="assets/iconmoon/css/iconmoon.css" rel="stylesheet" type="text/css">
        <!-- Lightbox CSS --> 
        <link href="assets/lightbox/css/lightbox.css" rel="stylesheet" type="text/css">
        <!-- Owl Carousel -->
        <link href="assets/owl-carousel/css/owl.carousel.min.css" rel="stylesheet" type="text/css">
        <!-- Animate -->
        <link href="css/animate.css" rel="stylesheet" type="text/css">
		<!-- Aos -->
        <link href="assets/aos/aos.css" rel="stylesheet" type="text/css">
        <!-- Custom Style -->
        <link href="css/custom.css" rel="stylesheet" type="text/css">
        <style>

            html, body {
            min-height: 100%;
            }
            body, div, form, input, select, p { 
            padding: 0;
            margin: 0;
            outline: none;
            font-family: Roboto, Arial, sans-serif;
            font-size: 16px;
            color: #eee;
            }
      
            h1, h3, h2 {
            text-transform: uppercase;
            font-weight: 400;
            color: ghostwhite;
            }
            h2 {
            margin: 0 0 0 8px;
            }
            .main-block {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100%;
            padding: 25px;
            background: rgba(29, 33, 41, 0.371); 
            }
           .right-block {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100%;
            padding: 25px;
            background: white;
            width: 100%;
            }
            .left-part, form {
            padding: 25px;
            }
            .left-part {
            text-align: center;
            }
            .fa-graduation-cap {
            font-size: 72px;
            }
            form {
            background: rgba(47, 47, 65, 0.432);
            border-radius: 15px;
            width: 75%; 
            }
      
            .title {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            }
            .info {
            display: flex;
            flex-direction: column;
            }
            input, select {
            padding: 5px;
            margin-bottom: 30px;
            background: transparent;
            border: none;
            border-bottom: 1px solid #eee;
            }
            input::placeholder {
            color: #eee;
            }
            option:focus {
            border: none;
            }
            option {
            background: black; 
            border: none;
            }
            .checkbox input {
            margin: 0 10px 0 0;
            vertical-align: middle;
            }
            .checkbox a {
            color: #e0b826;
            }
            .checkbox a:hover {
            color: #d7de85;
            }
            .btn-item, button {
            padding: 5px 5px;
            margin-top: 20px;
            border-radius: 5px; 
            border: none;
            background: orange; 
            text-decoration: none;
            font-size: 15px;
            font-weight: 400;
            color: #fff;
            }
            .btn-item {
            display: inline-block;
            margin: 20px 5px 0;
            }
            button {
            width: 50%;
            }
            button:hover, .btn-item:hover {
            background: #c39d37;
            }
            @media (min-width: 568px) {
            html, body {
            height: 100%;
            }
            .main-block {
         
            background: url(pexels-pixabay-274422.jpg) no-repeat center;
            background-size: cover;
            }
            .left-part, form {
            flex: 1;
            height: auto;
            }
             .right-part, form {
            flex: 1;
            height: auto;
            }
            }
            
          </style>
    </head>
    <body>
        <!-- Start Header -->
        <header> 
            <!-- Start Header Sec -->
            <div class="container header-sec">
                <div class="row"> 
                    <span class="col-xs-12 col-sm-3 logo"><a href="index-2.html"><img src="images/logo.png" id="logo" class="main img-responsive" alt="Fitness Gym"></a></span>
                    <div class="col-xs-12 col-sm-9 header-right">
                        <div class="header_search_outer">
                            <span class="icon-search-icon"></span>
                            <input type="text" value="" placeholder="Search" class="header_search"/>
                        </div>
                        <!-- Start Navigation -->
                        <nav class="navbar navbar-expand-md navbar-dark navbar-custom">
                            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                                <ul class="navbar-nav">
                                    <li class="nav-item">
                                        <a class="nav-link" href="index.php">Home</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="schedule.html">Tournament Schedule</a>
                                    </li>
                                 
                                    <li class="nav-item active">
                                        <a class="nav-link" href="inventory.php">Inventory</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="coachDetails.php">Coach details</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="playerDetails.php">Player details</a>
                                    </li>    
                                </ul>
                            </div>
                        </nav>
                        <!-- End Navigation --> 
                    </div>
                </div>
            </div>
            <!-- End Header Sec --> 
        </header>
        <!-- End Header --> 

        <!-- Start Banner -->
        <div class="banner-outer inner-banner schedule-banner">
            <span class="banner-shadow"></span>
            <div class="container">
                <div class="content" data-aos="fade-down">
                    <h1>INVENTORY</h1>
                    <div class="breadcrumbs_outer">
                        <div class="container">
                            <ul class="breadcrumbs">
                                <li><a href="index.php">Home</a></li>
                                <li>Admin</li>
                                <li>Inventory</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner --> 
        <table width="  100%">
            <tr>
                <td>
                 <div class="main-block">
    
              <form action="inventorySend.php" method="post">
                <div class="title">
                  <i class="fas fa-pencil-alt"></i> 
                  <h3><b>Inventory</b></h3>
                </div>
                <div class="info">
                <input type="text" name="Item_ID" placeholder="Enter item ID" id="itemID" required>
                  <input type="text" name="itemName" placeholder="Item Name"  id="itemName" required>
                  <input type="number" name="Quantity" placeholder="Quantity" id="quantity" required>
                </div>
                
                <table width="120%">
                  <tr>
                  <td><button type="submit" name="btnAdd" onclick="validate()">Add</button></td>
                <td><button type="submit" name="btnUpdate" onclick="validate()">Update</button></td>
              </tr>
            </table>
        
              </form>
          </div>
        </td>
        <td>
        <div class="right-block">
           
        
        <form action="inventorySend2.php" method="POST">
        
           <div class="search">
              <input type="text" class="searchTerm" id="searchID" name="searchID" placeholder="Enter item ID">
              <button type="submit" class="searchButton" name="search">
                <i class="fa fa-search"></i>
             </button>
             <table width=" 100%">
                <tr>
        
            <td><button type="submit" name="btnView">View</button></td>
            <td><button type="submit" name="btnClear">Clear</button></td>
           
        </tr>
        </table>
           
        
              </form>
            </div>
        </td>
        </tr>
        </table>
        
        <!-- Scroll to top --> 
        <a href="#" class="scroll-top"><i class="fa fa-chevron-up" aria-hidden="true"></i></a> 

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
        <script src="js/jquery.min.js"></script> 
        <!-- Bootstrap JS --> 
        <script src="assets/bootstrap/js/bootstrap.min.js"></script> 
        <!-- Lightbox JS --> 
        <script src="assets/lightbox/js/lightbox.js"></script> 
        <!-- Owl Carousal JS --> 
        <script src="assets/isotope/js/isotope.min.js"></script> 
        <!-- Owl Carousal JS --> 
        <script src="assets/owl-carousel/js/owl.carousel.min.js"></script>
        <!-- Aos JS --> 
        <script src="assets/aos/aos.js"></script>
        <!-- CounterUp JS --> 
        <script src="assets/counterup/counterup.min.js"></script>
        <script src="assets/counterup/waypoints.min.js"></script>  
        <!-- Custom JS --> 
        <script src="js/custom.js"></script>
        <!-- validation part -->
        <!-- <script>
            function validate(){
                     var id=document.getElementById("itemID").value;
                     var name=document.getElementById("itemName").value;
                     var quantity=document.getElementById("quantity").value;
                    
                   
 
                     if (id== null || id == "" && name == null || name == "" && quantity == null || quantity == "") {
                         alert("Inputs can't be Blank");
                     }
                     else if (id == null || id == "") {
                         alert("Item id can't be Blank");
                     }
                     else if (name== null || name== "") {
                         alert("Itam name can't be Blank");
                     }
                     else if(quantity=="" || quantity==null){
                         alert("Quantity can't be Blank...");
                     }
                    
                   
                 }
            
                 
         </script> -->
    </body>

</html>