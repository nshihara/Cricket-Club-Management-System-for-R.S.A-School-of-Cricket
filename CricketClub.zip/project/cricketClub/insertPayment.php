<?php
$con = new mysqli("localhost","root","","cricket");

if(!$con)
{
    echo "Can't connect the the database";
}
$id=$_POST["Payment_ID"];
$P_ID=$_POST["P_ID"];
$date=$_POST["P_Date"];
$amount=$_POST["P_Amount"];



$sql="INSERT INTO `payment`(`payment_ID`, `P_ID`, `Payment_date`, `P_amount`) VALUES ('$id','$P_ID','$date',$amount)";

if(mysqli_query($con,$sql)){
    echo "<script type='text/javascript'>alert('Succesfully Added...!');
    window.location='payments.php';
    </script>";

}else{
    echo "<script type='text/javascript'>alert('Invalid input,Please try again...!');
    window.location='payments.php';
    </script>";
}
mysqli_close($con);
?>