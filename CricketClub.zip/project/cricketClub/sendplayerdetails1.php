<html>
    <head>
        <style>
            #ok{
                background-color: #e0b826;
                width:200px;
                padding: 10px;
                border-radius:10px;
                font-weight:bold;
            }
            #item{
                font-family: Roboto, Arial, sans-serif;
                font-size: 20px;
                font-weight: 400;
                text-align: center;
                border:1px solid black;
                width:500px;
                margin-left:450px;
                background-color: rgba(59, 58, 58, 0.549);
                border-radius:10px;
                padding: 50px;


            }
            td{
                text-align: left;
            }
        </style>
    </head>
    <body>
<?php
$con = new mysqli("localhost","root","","cricket");

if(!$con)
{
    echo "Can't connect the the database";
}


$searchID=$_POST['searchID'];

 if(isset($_POST["btnClear"])){
    
    $sql="DELETE FROM `player` WHERE `P_ID`='$searchID'";

    if(mysqli_query($con,$sql)){
        echo "<script type='text/javascript'>alert('Record has been Deletd succeefully');
        window.location='playerDetails.php';
        </script>";

    }else{
        echo "<script type='text/javascript'>alert('No search results for that ID,Please try again...!');
        window.location='playerDetails.php';
        </script>";
    }
    mysqli_close($con);
}
else if (isset($_POST['btnView'])) {
   
    $sql="SELECT `P_ID`, `P_Name`, `P_DOB`, `P_Address`, `P_NIC`, `P_Email`, `P_Telnum`, `Addmission_Date` FROM `player` WHERE `P_ID`='$searchID'";
    $result=mysqli_query($con,$sql);

    

    if(mysqli_query($con,$sql)){
        echo "<table id='item'>
        ";
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr><td>Player ID</td>
                      <td> :".$row["P_ID"]."</td></tr>
                      <td>Player Name</td>
                      <td> :".$row["P_Name"]."</td></tr>
                      <td>Date of Birthdate</td>
                      <td> :".$row["P_DOB"]."</td><tr>
                      <td>Address</td>
                      <td> :".$row["P_Address"]."</td></tr>
                      <td>NIC number</td>
                      <td> :".$row["P_NIC"]."</td></tr>
                      <td>Email</td>
                      <td> :".$row["P_Email"]."</td></tr>
                      <td>Telphone number</td>
                      <td> :".$row["P_Telnum"]."</td></tr>
                      <td>Addmission date</td>
                      <td> :".$row["Addmission_Date"]."</td>
            </tr>";



            /*echo "Player ID:";
            echo $row["P_ID"];
            echo "<br><br>Player Name:";
            echo $row["P_Name"];
            echo "<br><br>Date of Birthdate:";
            echo $row["P_DOB"];
            echo "<br><br>Address:";
            echo $row["P_Address"];
            echo "<br><br>NIC number:";
            echo $row["P_NIC"];
            echo "<br><br>Email:";
            echo $row["P_Email"];
            echo "<br><br>Telphone number:";
            echo $row["P_Telnum"];
            echo "<br><br>Addmission date:";
            echo $row["Addmission_Date"];*/
            
        
        }
        echo "</table>";
        echo "<br><br><a href='playerDetails.php'> <button id='ok' type='submit' name='btnView'>OK</button></a>";
    }

    }
    else if (isset($_POST['btnViewAll'])) {
   
        $sql="SELECT * FROM `player` ";
        $result=mysqli_query($con,$sql);
    
        
    
        if(mysqli_query($con,$sql)){
            echo "<table id='item'>
            <tr><th>Player ID</th>
            <th>Player Name</th>
            <th>Date of Birthdate</th>
            <th>Address</th>
            <th>NIC number</th>
            <th>Email</th>
            <th>Telphone number</th>
            <th>Addmission date</th></tr>
            ";
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                          <td> ".$row["P_ID"]."</td>
                          
                          <td> ".$row["P_Name"]."</td>
                         
                          <td> ".$row["P_DOB"]."</td>
                         
                          <td> ".$row["P_Address"]."</td>
                          
                          <td> ".$row["P_NIC"]."</td>
                          
                          <td> ".$row["P_Email"]."</td>
                          
                          <td> ".$row["P_Telnum"]."</td>
                          
                          <td> ".$row["Addmission_Date"]."</td>
                </tr>";
    
    
    
                /*echo "Player ID:";
                echo $row["P_ID"];
                echo "<br><br>Player Name:";
                echo $row["P_Name"];
                echo "<br><br>Date of Birthdate:";
                echo $row["P_DOB"];
                echo "<br><br>Address:";
                echo $row["P_Address"];
                echo "<br><br>NIC number:";
                echo $row["P_NIC"];
                echo "<br><br>Email:";
                echo $row["P_Email"];
                echo "<br><br>Telphone number:";
                echo $row["P_Telnum"];
                echo "<br><br>Addmission date:";
                echo $row["Addmission_Date"];*/
                
            
            }
            echo "</table>";
            echo "<br><br><a href='playerDetails.php'> <button id='ok' type='submit' name='btnView'>OK</button></a>";
                
    
        }


    else{
        echo "<script type='text/javascript'>alert('No search results for that ID,Please try again...!');
        window.location='playerDetails.php';
        </script>";
    }
    mysqli_close($con);;
}
?>
   </body>
</html>