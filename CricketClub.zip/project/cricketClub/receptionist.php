<!doctype html>
<html lang="en">
    
<head>
        <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
        <title>Cricket Club</title>
        <!-- Reset CSS -->
        <link href="css/reset.css" rel="stylesheet" type="text/css">
        <!-- Bootstrap -->
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <!-- Font Awesome -->
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!-- Iconmoon -->
        <link href="assets/iconmoon/css/iconmoon.css" rel="stylesheet" type="text/css">
        <!-- Lightbox CSS --> 
        <link href="assets/lightbox/css/lightbox.css" rel="stylesheet" type="text/css">
        <!-- Owl Carousel -->
        <link href="assets/owl-carousel/css/owl.carousel.min.css" rel="stylesheet" type="text/css">
        <!-- Animate -->
        <link href="css/animate.css" rel="stylesheet" type="text/css">
		<!-- Aos -->
        <link href="assets/aos/aos.css" rel="stylesheet" type="text/css">
        <!-- Custom Style -->
        <link href="css/custom.css" rel="stylesheet" type="text/css">
        <style>
            h1{
                font-family: Arial, Helvetica, sans-serif;
                border: 1px solid black;
                background-color: rgba(209, 141, 23, 0.805);   
                width: 1000px;    
                
            }
            #overlay {
                position: fixed;
                display: none;
                width: 80%;
                height: 70%;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: rgba(44, 59, 73, 0.91);
                z-index: 2;
                cursor: pointer;
                margin-left: 100px;
                margin-top: 150px;
            }

            #text{
                position: absolute;
                top: 50%;
                left: 50%;
                font-size: 50px;
                color: white;
                transform: translate(-50%,-50%);
                -ms-transform: translate(-50%,-50%);
            }
            #btn{
                font-family: Arial, Helvetica, sans-serif;
                border: 1px solid black;
                background-color: rgba(209, 141, 23, 0.805); 
                color: white;
                width: 1000px;
                padding: 20px;
                font-size: 30px;
                font-weight: bold;
            }
            h3{
                color: white;
                border: 1px solid black;
                background-color: rgba(237, 169, 42, 0.696);
                width: 100%;
                padding: 20px;
                
            }
        </style>
    </head>
    <body>
        <!-- Start Header -->
        <header> 
            <!-- Start Header Sec -->
            <div class="container header-sec">
                <div class="row"> 
                    <span class="col-xs-12 col-sm-3 logo"><a href="index-2.html"><img id="logo" src="images/logo.png" class="main img-responsive" alt="Fitness Gym"><img src="https://media.istockphoto.com/id/641189676/photo/cricket-stadium.jpg?s=612x612&w=0&k=20&c=6aUm1D7NiTTR6ZC4MCcLW2zBnMbIwfqDqc8NBIDATn4=" class="fix img-responsive" alt=""></a></span>
                    <div class="col-xs-12 col-sm-9 header-right">
                        <div class="header_search_outer">
                            <span class="icon-search-icon"></span>
                            <input type="text" value="" placeholder="Search" class="header_search"/>
                        </div>
                        <!-- Start Navigation -->
                        <nav class="navbar navbar-expand-md navbar-dark navbar-custom">
                            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                                <ul class="navbar-nav">
                                    <li class="nav-item">
                                        <a class="nav-link" href="index.php">Home</a>
                                    </li>
                                    
                                </ul>
                            </div>
                        </nav>
                        <!-- End Navigation --> 
                    </div>
                </div>
            </div>
            <!-- End Header Sec --> 
        </header>
        <!-- End Header --> 


        <div class="banner-outer inner-banner  about-us-banner">
            <span class="banner-shadow"></span>
            <div class="container">
                <div class="content aos-init aos-animate" data-aos="fade-down">
                    
                   <a href="registration form.php"> <h1 style="font-size: 30px;margin-left: 50px;">STUDENT REGISTRATION</h1></a><br><br>
            
                    <div id="overlay" onclick="off()">
                        <div id="text">
                        <ul>
                            <li><a href="coachAttendance.php"><h3>COACH ATTENDANCE</h3></a></li><br><br>
                            <li> <a href="playerAttendance.php"><h3>PLAYER ATTENDANCE</h3></a></li><br>
                        </ul></div>
                      </div>
                      
                    <div style="padding:20px">
                        <button id="btn" onclick="on()">RECORD ATTENDANCE</button>
                      </div><br><br>

                    <a href="payments.php"><h1 style="font-size: 30px;margin-left: 50px;">PAYMENTS</h1></a><br><br>
                </div>
            </div>
        </div>
        <script>
            function on() {
              document.getElementById("overlay").style.display = "block";
            }
            
            function off() {
              document.getElementById("overlay").style.display = "none";
            }
            </script>
    </body>

</html>