<!doctype html>
<html lang="en">
    
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,height=device-height,initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
        <title>Cricket Club</title>
        <!-- Reset CSS -->
        <link href="css/reset.css" rel="stylesheet" type="text/css">
        <!-- Bootstrap -->
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <!-- Font Awesome -->
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!-- Iconmoon -->
        <link href="assets/iconmoon/css/iconmoon.css" rel="stylesheet" type="text/css">
        <!-- Lightbox CSS --> 
        <link href="assets/lightbox/css/lightbox.css" rel="stylesheet" type="text/css">
        <!-- Owl Carousel -->
        <link href="assets/owl-carousel/css/owl.carousel.min.css" rel="stylesheet" type="text/css">
        <!-- Animate -->
        <link href="css/animate.css" rel="stylesheet" type="text/css">
		<!-- Aos -->
        <link href="assets/aos/aos.css" rel="stylesheet" type="text/css">
        <!-- Custom Style -->
        <link href="css/custom.css" rel="stylesheet" type="text/css">
        <style>

            html, body {
            min-height: 100%;
            }
            body, div, form, input, select, p { 
            padding: 0;
            margin: 0;
            outline: none;
            font-family: Roboto, Arial, sans-serif;
            font-size: 16px;
            color: #eee;
            }
      
            h1, h3, h2 {
            text-transform: uppercase;
            font-weight: 400;
            color: ghostwhite;
            }
            h2 {
            margin: 0 0 0 8px;
            }
            .main-block {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100%;
            padding: 25px;
            background: rgba(29, 33, 41, 0.371); 
            }
           .right-block {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100%;
            padding: 25px;
            background: white;
            width: 100%;
            }
            .left-part, form {
            padding: 25px;
            }
            .left-part {
            text-align: center;
            }
            .fa-graduation-cap {
            font-size: 72px;
            }
            form {
            background: rgba(47, 47, 65, 0.432);
            border-radius: 15px;
            width: 75%; 
            }
      
            .title {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            }
            .info {
            display: flex;
            flex-direction: column;
            }
            input, select {
            padding: 5px;
            margin-bottom: 30px;
            background: transparent;
            border: none;
            border-bottom: 1px solid #eee;
            }
            input::placeholder {
            color: #eee;
            }
            option:focus {
            border: none;
            }
            option {
            background: black; 
            border: none;
            }
            .checkbox input {
            margin: 0 10px 0 0;
            vertical-align: middle;
            }
            .checkbox a {
            color: #e0b826;
            }
            .checkbox a:hover {
            color: #d7de85;
            }
            .btn-item, button {
            padding: 5px 5px;
            margin-top: 20px;
            border-radius: 5px; 
            border: none;
            background: orange; 
            text-decoration: none;
            font-size: 15px;
            font-weight: 400;
            color: #fff;
            }
            .btn-item {
            display: inline-block;
            margin: 20px 5px 0;
            }
            button {
            width: 50%;
            }
            button:hover, .btn-item:hover {
            background: #c39d37;
            }
            @media (min-width: 568px) {
            html, body {
            height: 100%;
            }
            .main-block {
         
            background: url(pexels-pixabay-274422.jpg) no-repeat center;
            background-size: cover;
            }
            .left-part, form {
            flex: 1;
            height: auto;
            }
             .right-part, form {
            flex: 1;
            height: auto;
            }
            }
          </style>
    </head>
    <body>
        <!-- Start Header -->
        <header> 
            <!-- Start Header Sec -->
            <div class="container header-sec">
                <div class="row"> 
                    <span class="col-xs-12 col-sm-3 logo"><a href="index-2.html"><img src="images/logo.png" id="logo" class="main img-responsive" alt="Fitness Gym"></a></span>
                    <div class="col-xs-12 col-sm-9 header-right">
                        <div class="header_search_outer">
                            <span class="icon-search-icon"></span>
                            <input type="text" value="" placeholder="Search" class="header_search"/>
                        </div>
                        <!-- Start Navigation -->
                        <nav class="navbar navbar-expand-md navbar-dark navbar-custom">
                            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                                <ul class="navbar-nav">
                                    <li class="nav-item">
                                        <a class="nav-link" href="index.php">Home</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="schedule.html">Tournament Schedule</a>
                                    </li>
                                 
                                    <li class="nav-item">
                                        <a class="nav-link" href="inventory.php">Inventory</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="coachDetails.php">Coach details</a>
                                    </li>
                                    <li class="nav-item active">
                                        <a class="nav-link" href="playerDetails.php">Player details</a>
                                    </li>    
                                </ul>
                            </div>
                        </nav>
                        <!-- End Navigation --> 
                    </div>
                </div>
            </div>
            <!-- End Header Sec --> 
        </header>
        <!-- End Header --> 

        <!-- Start Banner -->
        <div class="banner-outer inner-banner schedule-banner">
            <span class="banner-shadow"></span>
            <div class="container">
                <div class="content" data-aos="fade-down">
                    <h1>PLAYER DETAILS</h1>
                    <div class="breadcrumbs_outer">
                        <div class="container">
                            <ul class="breadcrumbs">
                                <li><a href="index.php">Home</a></li>
                                <li>Admin</li>
                                <li>Player Details</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner --> 
        <table width="  100%">
            <tr>
                <td>
                 <div class="main-block">
    
              <form action="sendplayerdetail.php" method="post">
                <div class="title">
                  <i class="fas fa-pencil-alt"></i> 
                  <h3><b>Player Details</b></h3>
                </div>
                <div class="info">
                  <input type="text" name="P_ID" placeholder="Enter Player ID" id="P_ID" required>
                  <input type="text" name="P_Name" placeholder="Player Name" id="name" required>
                  Date of Birth
                  <input type="date" name="P_DOB" placeholder="Date of Birth" id="dob" required>
                  <input type="text" name="P_Address" placeholder="Address" id="address" required>
                  <input type="text" name="P_NIC" placeholder="NIC" id="nic" pattern="[0-9]{12}" required>
                  <input type="text" name="P_Email" placeholder="Email" id="email" pattern="[^@\s]+@[^@\s]+" required>
                  <input type="text" name="P_Telnum" placeholder="Telephone Number" id="telno" pattern="[0][0-9]{9}" required>
                  Addmision Date
                  <input type="date" name="Addmission" placeholder="Addmision Date" id="Adm" >
                </div>
               
                <table width="120%">
                  <tr>
                <td><button type="submit" name="btnAdd" onclick="validate()">ADD</button></td>
                <td><button type="submit" name="btnUpdate" onclick="validate()">Update</button></td>
              </tr>
            </table>
        
              </form>
          </div>
        </td>
        <td>
          <div class="right-block">
           
        
              <form action="sendplayerdetails1.php" method="POST">
        
           <div class="search">
              <input type="text" class="searchTerm" id="searchID" name="searchID" placeholder="Enter player ID">
              <button type="submit" class="searchButton" name="search">
                <i class="fa fa-search"></i>
             </button>
             <table width=" 100%">
                <tr>
        
            
                    <td><button type="submit" name="btnView">View</button> </td> 
                     
                   <td> <button type="submit" name="btnClear">Clear</button> </td>
                   <td><button type="submit" name="btnViewAll">View Player Details</button> </td>
        </tr>
        </table>
           
        
              </form>
            </div>
        </td>
        </tr>
        </table>

        <!-- Scroll to top --> 
        <a href="#" class="scroll-top"><i class="fa fa-chevron-up" aria-hidden="true"></i></a> 

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
        <script src="js/jquery.min.js"></script> 
        <!-- Bootstrap JS --> 
        <script src="assets/bootstrap/js/bootstrap.min.js"></script> 
        <!-- Lightbox JS --> 
        <script src="assets/lightbox/js/lightbox.js"></script> 
        <!-- Owl Carousal JS --> 
        <script src="assets/isotope/js/isotope.min.js"></script> 
        <!-- Owl Carousal JS --> 
        <script src="assets/owl-carousel/js/owl.carousel.min.js"></script>
        <!-- Aos JS --> 
        <script src="assets/aos/aos.js"></script>
        <!-- CounterUp JS --> 
        <script src="assets/counterup/counterup.min.js"></script>
        <script src="assets/counterup/waypoints.min.js"></script>  
        <!-- Custom JS --> 
        <script src="js/custom.js"></script>
        <!-- <script>
            function validate(){
                    var pid=document.getElementById("P_ID").value;
                    var name=document.getElementById("name").value;
                    var dob=document.getElementById("dob").value;
                    var address=document.getElementById("address").value;
                    var nic=document.getElementById("nic").value;
                    var tel=document.getElementById("telno").value;
                    var email=document.getElementById("email").value;
                    var add=document.getElementById("adm").value;
                   

                    if (name == null || name == "" && tel == null || tel == "" && email == null || email == "" && pid == null || pid == "" && nic == null || nic == "" && address == null || address == "" && dob == null || dob == "" && add == null || add == "") {
                        alert("Inputs can't be Blank")
                    }
                    else if (tel == null || tel == "") {
                        alert("Telephone number can't be Blank");
                    }
                    else if (email == null || email == "") {
                        alert("Email Address can't be Blank");
                    }
                    else if(name=="" || name==null){
                        alert("Name can't be Blank...");
                    }
                    else if (pid == null || pid == "") {
                        alert("Player id can't be Blank");
                    }
                    else if(nic=="" || nic==null){
                        alert("NID number can't be Blank...");
                    }
                    else if (address == null || address == "") {
                        alert("Address can't be Blank");
                    }
                    else if(dob=="" || dob==null){
                        alert("NID number can't be Blank...");
                    }
                    else if (add == null || add== "") {
                        alert("Address can't be Blank");
                    }

                    else{
                        var emailA=document.getElementById("email").value;  
                        var atP=emailA.indexOf("@");  
                        var dotP=emailA.lastIndexOf(".");  
                        if (atP<1 || dotP<atP+2 || dotP+2>=emailA.length){  
                            alert("Please enter a valid e-mail address");  
                            return false;  
                     } 
                        var num=document.getElementById("telno").value;
                        var phoneno = /^\d{10}$/;
                        if(num.value.match(phoneno))
                            {
                        return true;
                            }
                        else
                            {
                            alert("message");
                            return false;
                    }
                    }
                  
                     
                    
                }
                function validateemail(){  
                     var emailA=document.getElementById("email").value;  
                     var atP=emailA.indexOf("@");  
                     var dotP=emailA.lastIndexOf(".");  
                     if (atP<1 || dotP<atP+2 || dotP+2>=emailA.length){  
                         alert("Please enter a valid e-mail address");  
                         return false;  
                     }  
                 }  
                 function phonenumber(){
                    var num=document.getElementById("telno").value;
                    var phoneno = /^\d{10}$/;
                    if(num.value.match(phoneno))
                        {
                    return true;
                        }
                    else
                        {
                        alert("message");
                        return false;
                    }
                }
                function idValidation(){

                }
        </script> -->
    </body>

</html>