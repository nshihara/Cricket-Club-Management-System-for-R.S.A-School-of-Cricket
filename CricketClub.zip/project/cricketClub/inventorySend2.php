<html>
    <head>
        <style>
            #ok{
                background-color: #e0b826;
                width:200px;
                padding: 10px;
                border-radius:10px;
                font-weight:bold;
                margin-left:600px;
            }
            #item{
                font-family: Roboto, Arial, sans-serif;
                font-size: 20px;
                font-weight: 400;
                text-align: center;
                border:1px solid black;
                width:500px;
                margin-left:450px;
                background-color: rgba(59, 58, 58, 0.549);
                border-radius:10px;
                padding: 50px;

            }
            td{
                text-align: left;
            }
        </style>
    </head>
    <body>
    <?php
$con = new mysqli("localhost","root","","cricket");

if(!$con)
{
    echo "Can't connect the the database";
}


$searchID=$_POST['searchID'];

 if(isset($_POST["btnClear"])){
    
    $sql="DELETE FROM `inventory` WHERE `ItemID`='$searchID'";

    if(mysqli_query($con,$sql)){
        echo "<script type='text/javascript'>alert('Record has been Deletd succeefully');
        window.location='inventory.php';
        </script>";

    }else{
        echo "<script type='text/javascript'>alert('No search results for that ID,Please try again...!');
        window.location='inventory.php';
        </script>";
    }
    mysqli_close($con);
}
else if (isset($_POST['btnView'])) {
    $sql="SELECT `ItemID`, `I_name`, `quantity` FROM `inventory` WHERE `ItemID`='$searchID'";
    $result=mysqli_query($con,$sql);

    

    if(mysqli_query($con,$sql)){
        echo "<table id='item'>"
        ;
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr><td>Item ID</td>
                      <td>".$row["ItemID"]."</td></tr>
                      <td>I_name</td>
                      <td>".$row["I_name"]."</td></tr>
                      <td>Item Quantity</td>
                      <td>".$row["quantity"]."</td>
            </tr>";

            /*echo $row["ItemID"];
            echo "<br>Item name:";
            echo $row["I_name"];
            echo "<br>Item Quantity:";
            echo $row["quantity"];*/
            
           
        }
        echo "</table>";
        echo "<br><br><a href='inventory.php'> <button id='ok' type='submit' name='btnView'>OK</button></a>";
            echo"</div>";
    }

    }else if(isset($_POST["btnViewAll"])){
        $sql="SELECT * FROM `inventory`";
    $result=mysqli_query($con,$sql);

    

    if(mysqli_query($con,$sql)){
        echo "<table id='item'>
        <tr><th>ItemID</th>
        <th>ItemID</th>
        <th>quantity</th>";
        ;
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                      <td>".$row["ItemID"]."</td>
                      
                      <td>".$row["I_name"]."</td>
                      
                      <td>".$row["quantity"]."
            </tr>";

            /*echo $row["ItemID"];
            echo "<br>Item name:";
            echo $row["I_name"];
            echo "<br>Item Quantity:";
            echo $row["quantity"];*/
           
           
        }
        echo "</table>";
        echo "<br><br><a href='inventory.php'> <button id='ok' type='submit' name='btnView'>OK</button></a>";
        echo"</div>";

    }
    else{
        echo "<script type='text/javascript'>alert('No search results for that ID,Please try again...!');
        window.location='inventory.php';
        </script>";
    }
    mysqli_close($con);;
}
?>
        
    </body>
</html>