<?php
	$host="localhost";
	$user = "root";
	$pass = "";
	$db = "form";

	$conn=mysqli_connect($host,$user,$pass,$db);

	if(!$conn){
		die("could't connect mysql server:".mysql_error());
	}
?> 