<?php
$con = new mysqli("localhost","root","","cricket");

if(!$con)
{
    echo "Can't connect the the database";
}
$id=$_POST["P_ID"];
$name=$_POST["P_Name"];
$NIC=$_POST["P_NIC"];
$DOB=$_POST["P_DOB"];
$address=$_POST["P_Address"];
$email=$_POST["P_Email"];
$phone=$_POST["P_Telnum"];
$addDate=$_POST["Addmission"];

if(isset($_POST["btnAdd"])){
$sql="INSERT INTO `player`(`P_ID`, `P_Name`, `P_DOB`, `P_Address`, `P_NIC`, `P_Email`, `P_Telnum`, `Addmission_Date`) VALUES 
('$id','$name','$DOB','$address','$NIC','$email','$phone','$addDate')";

if(mysqli_query($con,$sql)){
    echo "<script type='text/javascript'>alert('Succesfully Added...!');
    window.location='playerDetails.php';
    </script>";

}else{
    echo "<script type='text/javascript'>alert('Invalid input,Please try again...!');
    window.location='playerDetails.php';
    </script>";
}
mysqli_close($con);}
else if(isset($_POST["btnUpdate"])){

    $sql="UPDATE `player` SET `P_ID`='$id',`P_Name`='$name',`P_DOB`='$DOB',`P_Address`='$address',`P_NIC`='$NIC',`P_Email`='$email',`P_Telnum`='$phone',`Addmission_Date`='$addDate' WHERE `P_ID`='$id'";
    if(mysqli_query($con,$sql)){
    echo "<script type='text/javascript'>alert('Succesfully updated...!');
    window.location='playerDetails.php';
    </script>";

    }else{
        echo "<script type='text/javascript'>alert('Invalid ,Please try again...!');
        window.location='playerDetails.php';
        </script>";
    }
    mysqli_close($con);
    }
?>