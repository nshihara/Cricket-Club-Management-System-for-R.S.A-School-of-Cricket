<!doctype html>
<html lang="en">
    

<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
        <title>Cricket Club</title>
        <!-- Reset CSS -->
        <link href="css/reset.css" rel="stylesheet" type="text/css">
        <!-- Bootstrap -->
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <!-- Font Awesome -->
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!-- Iconmoon -->
        <link href="assets/iconmoon/css/iconmoon.css" rel="stylesheet" type="text/css">
        <!-- Lightbox CSS --> 
        <link href="assets/lightbox/css/lightbox.css" rel="stylesheet" type="text/css">
        <!-- Owl Carousel -->
        <link href="assets/owl-carousel/css/owl.carousel.min.css" rel="stylesheet" type="text/css">
        <!-- Animate -->
        <link href="css/animate.css" rel="stylesheet" type="text/css">
        <!-- Aos -->
        <link href="assets/aos/aos.css" rel="stylesheet" type="text/css">
        <!-- Custom Style -->
        <link href="css/custom.css" rel="stylesheet" type="text/css">
        <style type="text/css">
          #success_message{ display: none;}
           button{
                background-color: black;
                color: white;
                width: 35%;
                border: 2px solid black;
                text-align: center;
                font-weight: bold;
                font-family: "Georgia"; 
                margin-left: 3%;
                font-size: 15px;
            }
            form{
                margin-top: 50px;
            }
            label{
                font-weight: bold;
            }
            #btnReg{
                background-color: black;
                color: white;
                width: 35%;
                border: 2px solid black;
                text-align: center;
                font-weight: bold;
                font-family: "Georgia"; 
                margin-left: 3%;
                font-size: 15px;
            }
        </style>
    </head>
    <body>
        <!-- Start Header -->
        <header> 
            <!-- Start Header Sec -->
            <div class="container header-sec">
                <div class="row"> 
                    <span class="col-xs-12 col-sm-3 logo"><a href="index-2.html"><img src="C:\Users\HIRUNI\Desktop\Kuntosala-HTML5-Template\photo_2022-11-13_08-32-43.jpg" class="main img-responsive" alt=""></a></span>
                    <div class="col-xs-12 col-sm-9 header-right">
                        <div class="header_search_outer">
                            <span class="icon-search-icon"></span>
                            <input type="text" value="" placeholder="Search" class="header_search"/>
                        </div>
                        <!-- Start Navigation -->
                        <nav class="navbar navbar-expand-md navbar-dark navbar-custom">
                            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                                <ul class="navbar-nav">
                                    <li class="nav-item">
                                        <a class="nav-link" href="index.php">Home</a>
                                    </li>                                 
                                    <li class="nav-item active">
                                        <a class="nav-link" href="registration form.php">Student Registraion</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="receptionist.php">Record Attendance</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="payments.php">Payments</a>
                                    </li>        
                                </ul>
                            </div>
                        </nav>
                        <!-- End Navigation --> 
                    </div>
                </div>
            </div>
            <!-- End Header Sec --> 
        </header>
        <!-- End Header --> 

        <!-- Start Banner -->
        <div class="banner-outer inner-banner  about-us-banner">
            <span class="banner-shadow"></span>
            <div class="container">
                <div class="content" data-aos="fade-down">
                    <h1>STUDENT REGISTRATION FORM</h1>
                    <div class="breadcrumbs_outer">
                        <div class="container">
                            <ul class="breadcrumbs">
                                <li><a href="index.php">Home</a></li>
                                <li>Reception</li>
                                <li>Registraion Form</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner --> 

        <!-- Start About Top Sec -->
                            
        <div class="container">

            <form class="well form-horizontal" action="insert.php" method="post"  id="contact_form">
            <div id="msg" class="form-group"></div>
                <fieldset>
                    <table>
                        <tr>
                            <label>Player ID</label>
                        </tr>
                        <tr>
                            <input  name="P_ID" placeholder="P-01" class="form-control"  type="text" id="P_ID"  required>
                        </tr>
                        <tr>
                            <label>Full Name</label>    
                        </tr>
                        <tr>
                            <input  name="P_Name" placeholder="Full Name" class="form-control"  type="text" id="name" required>
                        </tr>
                        
                        <tr>
                            <label>Date of birth</label>    
                        </tr>
                        <tr>
                            <input  name="P_DOB" placeholder="Date of birth" class="form-control"  type="Date" id="dob" required>
                        </tr>
                        <tr>
                            <label>Address</label>    
                        </tr>
                        <tr>
                            <textarea name="P_Address" placeholder="Address" class="form-control"  type="text" id="address" required></textarea>
                        </tr>
                        
                        <tr>
                            <label>NIC</label>    
                        </tr>
                        <tr>
                            <input  name="P_NIC" placeholder="NIC" class="form-control"  type="text" id="nic" pattern="[0-9]{12}" required>
                        </tr>
                        
                        <tr>
                            <label>Email</label>    
                        </tr>
                        <tr>
                            <input  name="P_Email" placeholder="Email" class="form-control"  type="text" id="email" pattern="[^@\s]+@[^@\s]+" required>
                        </tr>
                        <tr>
                            <label>Tele-Phone Number</label>    
                        </tr>
                        <tr>
                            <input  name="P_Telnum" placeholder="Tele-Phone Number" class="form-control"  type="text" id="telno" pattern="[0][0-9]{9}" required>
                        </tr>      
                        <tr>
                            <label>Admission date</label>    
                        </tr>
                        <tr>
                            <input  name="Admission_Date" placeholder="Admission date" class="form-control"  type="date" id="admission" required>
                        </tr>                            
                    </table>
                    
                    </fieldset>
                    <br><br><center>
                    <input id="btnReg" type="submit" value="register" > </button></center><br><br><br>
                </center>
                    
            </form>
           
        </div><!-- /.container -->


        <!-- End About Top sec --> 


        <!-- Scroll to top --> 
        <a href="#" class="scroll-top"><i class="fa fa-chevron-up" aria-hidden="true"></i></a> 

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
        <script src="js/jquery.min.js"></script> 
        <!-- Lightbox JS --> 
        <script src="assets/lightbox/js/lightbox.js"></script> 
        <!-- Owl Carousal JS --> 
        <script src="assets/isotope/js/isotope.min.js"></script> 
        <!-- Owl Carousal JS --> 
        <script src="assets/owl-carousel/js/owl.carousel.min.js"></script>
        <!-- Aos JS --> 
        <script src="assets/aos/aos.js"></script>
		<!-- CounterUp JS --> 
        <script src="assets/counterup/counterup.min.js"></script>
        <script src="assets/counterup/waypoints.min.js"></script>
        <!-- Custom JS --> 
        <script src="js/custom.js"></script>
        <!-- <script>
           function validate(){
                    var pid=document.getElementById("P_ID").value;
                    var name=document.getElementById("name").value;
                    var dob=document.getElementById("dob").value;
                    var address=document.getElementById("address").value;
                    var nic=document.getElementById("nic").value;
                    var tel=document.getElementById("telno").value;
                    var email=document.getElementById("email").value;
                   

                    if (name == null || name == "" && tel == null || tel == "" && email == null || email == "" && 
                    pid == null || pid == "" && nic == null || nic == "" && address == null || address == "") {
                        alert("Inputs can't be Blank")
                    }
                    else if (tel == null || tel == "") {
                        alert("Telephone number can't be Blank");
                    }
                    else if (email == null || email == "") {
                        alert("Email Address can't be Blank");
                    }
                    else if(name=="" || name==null){
                        alert("Name can't be Blank...");
                    }
                    else if (pid == null || pid == "") {
                        alert("Player id can't be Blank");
                    }
                    else if(nic=="" || nic==null){
                        alert("NID number can't be Blank...");
                    }
                    else if (address == null || address == "") {
                        alert("Address can't be Blank");
                    }

                    else{
                        var emailA=document.getElementById("email").value;  
                        var atP=emailA.indexOf("@");  
                        var dotP=emailA.lastIndexOf(".");  
                        if (atP<1 || dotP<atP+2 || dotP+2>=emailA.length){  
                            alert("Please enter a valid e-mail address");  
                            return false;  
                     } 
                        var num=document.getElementById("telno").value;
                        var phoneno = /^\d{10}$/;
                        if(num.value.match(phoneno))
                            {
                        return true;
                            }
                        else
                            {
                            alert("message");
                            return false;
                    }
                    }
                  
                     
                    
                }
                
               
        </script> -->
    </body>

</html>