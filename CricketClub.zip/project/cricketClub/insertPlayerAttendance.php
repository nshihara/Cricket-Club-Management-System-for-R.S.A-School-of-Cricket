<?php
$con = new mysqli("localhost","root","","cricket");

if(!$con)
{
    echo "Can't connect the the database";
}
$id=$_POST["P_ID"];
$month=$_POST["month"];
$date=$_POST["date"];
$att=$_POST["Attendancee"];



$sql="INSERT INTO `playerattendance`(`P_ID`, `month`, `date`, `P_Attendance`) VALUES ('$id','$month','$date','$att')";
if(mysqli_query($con,$sql)){
    echo "<script type='text/javascript'>alert('Succesfully Added...!');
    window.location='playerAttendance.php';
    </script>";

}else{
echo "<script type='text/javascript'>alert('Invalid input,Please try again...!');
window.location='playerAttendance.php';
</script>";
}
mysqli_close($con);
?>