<?php
$con = new mysqli("localhost","root","","cricket");

if(!$con)
{
    echo "Can't connect the the database";
}
$id=$_POST["C_ID"];
$name=$_POST["C_Name"];
$NIC=$_POST["C_NIC"];
$DOB=$_POST["C_DOB"];
$address=$_POST["C_Address"];


if(isset($_POST["btnAdd"])){

$sql="INSERT INTO `coach`(`C_ID`, `C_Name`, `C_DOB`, `C_Address`, `C_NIC`) VALUES ('$id','$name','$DOB','$address','$NIC')";

if(mysqli_query($con,$sql)){
    echo "<script type='text/javascript'>alert('Succesfully Added...!');
    window.location='coachDetails.php';
    </script>";

}else{
    echo "<script type='text/javascript'>alert('Invalid input,Please try again...!');
    window.location='coachDetails.php';
    </script>";
}

mysqli_close($con);}
else if(isset($_POST["btnUpdate"])){
  
    $sql="UPDATE `coach` SET `C_ID`='$id',`C_Name`='$name',`C_DOB`='$DOB',`C_Address`='$address',`C_NIC`='$NIC' WHERE `C_ID`='$id'";
    // $sql="UPDATE `coach` SET `C_ID`='$id',`C_Name`='$name',`C_DOB`='[value-3]',`C_Address`='[value-4]',`C_NIC`='[value-5]' WHERE 1
    if(mysqli_query($con,$sql)){
    echo "<script type='text/javascript'>alert('Succesfully updated...!');
    window.location='coachDetails.php';
    </script>";

    }else{
        echo "<script type='text/javascript'>alert('Invalid ,Please try again...!');
        window.location='coachDetails.php';
        </script>";
    }
    mysqli_close($con);
    }
?>