<!doctype html>
<html lang="en">
    
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
        <title>Cricket Club</title>
        <!-- Reset CSS -->
        <link href="css/reset.css" rel="stylesheet" type="text/css">
        <!-- Bootstrap -->
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <!-- Font Awesome -->
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!-- Iconmoon -->
        <link href="assets/iconmoon/css/iconmoon.css" rel="stylesheet" type="text/css">
        <!-- Lightbox CSS --> 
        <link href="assets/lightbox/css/lightbox.css" rel="stylesheet" type="text/css">
        <!-- Owl Carousel -->
        <link href="assets/owl-carousel/css/owl.carousel.min.css" rel="stylesheet" type="text/css">
        <!-- Animate -->
        <link href="css/animate.css" rel="stylesheet" type="text/css">
        <!-- Aos -->
        <link href="assets/aos/aos.css" rel="stylesheet" type="text/css">
        <!-- Custom Style -->
        <link href="css/custom.css" rel="stylesheet" type="text/css">
        
    </head>
    <body>
        <!-- Start Preloader -->
        <div id="loading">
          <div class="element">
            <div class="sk-folding-cube">
              <div class="sk-cube1 sk-cube"></div>
              <div class="sk-cube2 sk-cube"></div>
              <div class="sk-cube4 sk-cube"></div>
              <div class="sk-cube3 sk-cube"></div>
            </div>
          </div>
        </div>
        <!-- End Preloader -->
    
        <!-- Start Header -->
        <header> 
            <!-- Start Header Sec -->
            <div class="container header-sec">
                <div class="row"> 
                    <span class="col-xs-12 col-sm-3 logo"><a href="index-2.html"><img class="main" src="images/logo.png" alt="Fitness Gym"  id="logo"></a></span>
                    <div class="col-xs-12 col-sm-9 header-right">
                        <div class="header_search_outer">
                            <span class="icon-search-icon"></span>
                            <input type="text" value="" placeholder="Search" class="header_search"/>
                        </div>
                        <!-- Start Navigation -->
                        <nav class="navbar navbar-expand-md navbar-dark navbar-custom">
                            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                                <ul class="navbar-nav">
                                    <li class="nav-item active">
                                        <a class="nav-link" href="index.php">Home</a>
                                    </li>

                                    
                                </ul>
                            </div>
                        </nav>
                        <!-- End Navigation --> 
                    </div>
                </div>
            </div>
            <!-- End Header Sec --> 
        </header>
        <!-- End Header --> 

        <!-- Start Banner -->
        <div class="banner-outer">
            <span class="banner-shadow"></span>
            <div class="banner-image">
                <div class="container">
                    <div class="content" data-aos="fade-right">
                        <h1>R.S.A</h1>
                        <h2>SCHOOL OF CRICKET</h2>
                        <p>Don't practice until you get it right. Practice until you can't get it wrong.If you are passionate about cricket you can join with us. No matter what your age is. </p>
                        <a href="index.php" class="btn">JOIN WITH US</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner -->

        <!-- Start building -->
        <div class="building-outer">
            <div class="container">
                <div class="building-list">
                    <div class="row">
                        <div class="col-sm-4 col-xs-12">
                            <div class="building-box" id="box1">
                                <figure><img src="images/build1.png" alt=""></figure>
                                <h4>RECEPTION</h4>
                                <p id="p2"><ul>
                                    <li>Student Registraion</li>
                                    <li>Recode Attendence</li>
                                    <li>Payements</li>
                                  
                                    
                                </ul></p>
                                <a href="RecepLogin.php" class="btn" id="btn1">LOGIN</a>
                            </div>
                        </div>
                        <div class="col-sm-4 col-xs-12">
                            <div class="building-box" id="box2">
                                <figure id="img2"><img src="images/build2.png"  alt=""></figure>
                                <h4>ADMIN</h4>
                                <p id="p1"><ul>
                                    <li>Tournament Schedule</li>
                                    <li>Inventory</li>
                                    <li>Coach Details</li>
                                    <li>Player Details</li>
                                </ul></p>
                                <a href="AdminLogin.php" class="btn">LOGIN</a>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
        <!-- End building sec --> 

        
            <!-- Copy Rights --> 
            <div class="copy-rights-section">
                <div class="container">
                    <div class="row">
                         <div class="col-sm-12 col-xs-12">
                            <p style="font-family: Lucida Calligraphy;"><a target="_blank" href="https://www.templateshub.net"> <b><i>R.S.A School of cricket</i></b> </a></p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Copy Rights --> 
        </footer>
        <!-- End Footer --> 

        <!-- Scroll to top --> 
        <a href="#" class="scroll-top"><i class="fa fa-chevron-up" aria-hidden="true"></i></a> 

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
        <script src="js/jquery.min.js"></script> 
        <!-- Bootstrap JS --> 
        <script src="assets/bootstrap/js/bootstrap.min.js"></script> 
        <!-- Lightbox JS --> 
        <script src="assets/lightbox/js/lightbox.js"></script> 
        <!-- Owl Carousal JS --> 
        <script src="assets/isotope/js/isotope.min.js"></script> 
        <!-- Owl Carousal JS --> 
        <script src="assets/owl-carousel/js/owl.carousel.min.js"></script>
        <!-- Aos JS --> 
        <script src="assets/aos/aos.js"></script>
        <!-- CounterUp JS --> 
        <script src="assets/counterup/counterup.min.js"></script>
        <script src="assets/counterup/waypoints.min.js"></script>  
        <!-- Custom JS --> 
        <script src="js/custom.js"></script>
    </body>

</html>