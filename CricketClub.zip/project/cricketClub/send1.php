<!-- Admin Login -->
<?php

  $con = new mysqli("localhost","root","","cricket");

  if(!$con)
  {
      echo "Can't connect the the database";
  }
  $username=$_POST['username'];
  $password=$_POST['password'];

  $sql = "SELECT * FROM login_ WHERE username='$username' AND passWord_='$password'";
  $res = mysqli_query($con, $sql);
  $rows = mysqli_fetch_array($res);

  if (!$rows) {
    echo "<script type='text/javascript'>alert('Invalid Login,Please try again...!');
    window.location='AdminLogin.php';
    </script>";
  } else {
    echo "<script type='text/javascript'>alert('Succesfully logged in to the website...!');
    window.location='Admin.php';
    </script>";
  }

?>

