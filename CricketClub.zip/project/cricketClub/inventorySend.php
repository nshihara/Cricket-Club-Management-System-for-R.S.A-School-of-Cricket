<?php
$con = new mysqli("localhost","root","","cricket");

if(!$con)
{
    echo "Can't connect the the database";
}
$id=$_POST["Item_ID"];
$name=$_POST["itemName"];
$quantity=$_POST["Quantity"];


if(isset($_POST["btnAdd"])){
    $sql="INSERT INTO `inventory`(`ItemID`, `I_name`, `quantity`) VALUES ('$id','$name',$quantity)";

    if(mysqli_query($con,$sql)){
        echo "<script type='text/javascript'>alert('Succesfully Addeded...!');
        window.location='inventory.php';
        </script>";
    

    }else{
        echo "<script type='text/javascript'>alert('Invalid ,Please try again...!');
        window.location='inventory.php';
        </script>";
    }
    mysqli_close($con);
    }
else if(isset($_POST["btnUpdate"])){
    $sql="UPDATE `inventory` SET `ItemID`='$id',`I_name`='$name',`quantity`=$quantity WHERE `ItemID`='$id'";

    if(mysqli_query($con,$sql)){
    echo "<script type='text/javascript'>alert('Succesfully updated...!');
    window.location='inventory.php';
    </script>";

    }else{
        echo "<script type='text/javascript'>alert('Invalid ,Please try again...!');
        window.location='inventory.php';
        </script>";
    }
    mysqli_close($con);
    }

    

?>