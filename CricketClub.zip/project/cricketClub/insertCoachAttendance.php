<?php
$con = new mysqli("localhost","root","","cricket");

if(!$con)
{
    echo "Can't connect the the database";
}
$id=$_POST["C_ID"];
$month=$_POST["month"];
$date=$_POST["date"];
$att=$_POST["Attendancee"];



$sql="INSERT INTO `coachattendance`(`C_ID`, `month`, `date`, `C_Attendance`) VALUES ('$id','$month','$date','$att')";
if(mysqli_query($con,$sql)){
    echo "<script type='text/javascript'>alert('Succesfully Added...!');
    window.location='coachAttendance.php';
    </script>";

}else{
    echo "<script type='text/javascript'>alert('Invalid input,Please try again...!');
    window.location='coachAttendance.php';
    </script>";
}
mysqli_close($con);
?>
