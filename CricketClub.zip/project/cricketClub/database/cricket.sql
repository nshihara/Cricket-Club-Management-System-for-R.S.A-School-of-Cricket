-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 17, 2022 at 03:24 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cricket`
--

-- --------------------------------------------------------

--
-- Table structure for table `coach`
--

DROP TABLE IF EXISTS `coach`;
CREATE TABLE IF NOT EXISTS `coach` (
  `C_ID` varchar(20) NOT NULL,
  `C_Name` varchar(100) NOT NULL,
  `C_DOB` date NOT NULL,
  `C_Address` varchar(100) NOT NULL,
  `C_NIC` varchar(25) NOT NULL,
  PRIMARY KEY (`C_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coach`
--

INSERT INTO `coach` (`C_ID`, `C_Name`, `C_DOB`, `C_Address`, `C_NIC`) VALUES
('C05', 'fsdgfsdg', '2022-11-18', 'qwert', '123456789012');

-- --------------------------------------------------------

--
-- Table structure for table `coachattendance`
--

DROP TABLE IF EXISTS `coachattendance`;
CREATE TABLE IF NOT EXISTS `coachattendance` (
  `C_ID` varchar(20) NOT NULL,
  `month` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `C_Attendance` varchar(11) NOT NULL,
  PRIMARY KEY (`month`,`date`),
  KEY `C_ID_fk` (`C_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coachattendance`
--

INSERT INTO `coachattendance` (`C_ID`, `month`, `date`, `C_Attendance`) VALUES
('fgdf', 'aug', '2022-11-20', 'yes'),
('fgdf', 'jul', '2022-11-17', 'no'),
('fgdf', '', '2022-11-24', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
CREATE TABLE IF NOT EXISTS `inventory` (
  `ItemID` varchar(20) NOT NULL,
  `I_name` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`ItemID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`ItemID`, `I_name`, `quantity`) VALUES
('IN06', 'qwedwd', 423423),
('IN02', 'sgfsg', 22),
('IN04', 'hsh', 54),
('IN03', 'hsh', 3235435),
('IN05', 'ewfsed', 4234);

-- --------------------------------------------------------

--
-- Table structure for table `login_`
--

DROP TABLE IF EXISTS `login_`;
CREATE TABLE IF NOT EXISTS `login_` (
  `ID` varchar(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `passWord_` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_`
--

INSERT INTO `login_` (`ID`, `username`, `passWord_`) VALUES
('R01', 'reception', '1234'),
('A01', 'admin', '5678');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
CREATE TABLE IF NOT EXISTS `payment` (
  `payment_ID` varchar(20) NOT NULL,
  `P_ID` varchar(20) NOT NULL,
  `Payment_date` varchar(20) NOT NULL,
  `P_amount` int(11) NOT NULL,
  PRIMARY KEY (`payment_ID`,`Payment_date`),
  KEY `P_ID_fk` (`P_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_ID`, `P_ID`, `Payment_date`, `P_amount`) VALUES
('rewf', 'wdfs', '', 32),
('rewf', 'gdfg', '2022-11-17', 32),
('rewf', 'gdfg', '2022-11-26', 32),
('rewf66', 'wdfs', '2022-11-25', 6346),
('rewf667', 'gdfg', '2022-11-26', 32);

-- --------------------------------------------------------

--
-- Table structure for table `payroll`
--

DROP TABLE IF EXISTS `payroll`;
CREATE TABLE IF NOT EXISTS `payroll` (
  `salary_ID` varchar(20) NOT NULL,
  `C_ID` varchar(20) NOT NULL,
  `S_month` varchar(20) NOT NULL,
  `S_amount` int(11) NOT NULL,
  `S_date` date NOT NULL,
  PRIMARY KEY (`salary_ID`),
  KEY `C_ID_fk` (`C_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `player`
--

DROP TABLE IF EXISTS `player`;
CREATE TABLE IF NOT EXISTS `player` (
  `P_ID` varchar(20) NOT NULL,
  `P_Name` varchar(100) NOT NULL,
  `P_DOB` date NOT NULL,
  `P_Address` varchar(100) NOT NULL,
  `P_NIC` varchar(25) NOT NULL,
  `P_Email` varchar(100) NOT NULL,
  `P_Telnum` int(11) NOT NULL,
  `Addmission_Date` date NOT NULL,
  PRIMARY KEY (`P_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `player`
--

INSERT INTO `player` (`P_ID`, `P_Name`, `P_DOB`, `P_Address`, `P_NIC`, `P_Email`, `P_Telnum`, `Addmission_Date`) VALUES
('P08', 'wert', '2022-11-18', 'esrytgdfhg', '123456789091', 'dfgsd@dfghdf.hgdf', 323412345, '2022-11-26'),
('p05', 'efrwe', '2022-11-15', 'ryterfyhethy', '123456789345', 'dfgsd@dfghdf.hgdf', 123456789, '2022-11-16');

-- --------------------------------------------------------

--
-- Table structure for table `playerattendance`
--

DROP TABLE IF EXISTS `playerattendance`;
CREATE TABLE IF NOT EXISTS `playerattendance` (
  `P_ID` varchar(20) NOT NULL,
  `month` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `P_Attendance` varchar(11) NOT NULL,
  PRIMARY KEY (`month`,`date`),
  KEY `P_ID_fk` (`P_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `playerattendance`
--

INSERT INTO `playerattendance` (`P_ID`, `month`, `date`, `P_Attendance`) VALUES
('gdfg', 'sep', '2022-12-03', 'yes'),
('P8', 'sep', '2022-11-23', 'yes'),
('111', '', '2022-12-02', 'yes'),
('gdfg', '', '2022-11-26', 'yes'),
('', 'sep', '2022-11-24', 'yes'),
('PID001', '', '2022-11-18', 'yes'),
('', '', '2022-11-25', ''),
('', '', '2022-11-19', ''),
('', '', '2022-11-16', ''),
('', '', '2022-11-07', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
