<!doctype html>
<html lang="en">
    
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,height=device-height,initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
        <title>Cricket Club</title>
        <!-- Reset CSS -->
        <link href="css/reset.css" rel="stylesheet" type="text/css">
        <!-- Bootstrap -->
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <!-- Font Awesome -->
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!-- Iconmoon -->
        <link href="assets/iconmoon/css/iconmoon.css" rel="stylesheet" type="text/css">
        <!-- Lightbox CSS --> 
        <link href="assets/lightbox/css/lightbox.css" rel="stylesheet" type="text/css">
        <!-- Owl Carousel -->
        <link href="assets/owl-carousel/css/owl.carousel.min.css" rel="stylesheet" type="text/css">
        <!-- Animate -->
        <link href="css/animate.css" rel="stylesheet" type="text/css">
		<!-- Aos -->
        <link href="assets/aos/aos.css" rel="stylesheet" type="text/css">
        <!-- Custom Style -->
        <link href="css/custom.css" rel="stylesheet" type="text/css">
        <style>
            label{
                margin-left: 570px;
                font-weight: bold;
            }
            input{
                margin-left: 30px;
                width: 250px;
               
            }
            select{
                margin-left: 30px;
                width: 250px;
            }
            button{
                background-color: black;
                color: white;
                width: 200px;
                border: 2px solid black;
                text-align: center;
                font-weight: bold;
                font-family: "Georgia"; 
                margin-left: 650px;
                font-size: 15px;
            }
            #attendancee{
                margin-left: 0px;
            }
        </style>
    </head>
    <body>
        <!-- Start Header -->
        <header> 
            <!-- Start Header Sec -->
            <div class="container header-sec">
                <div class="row"> 
                    <span class="col-xs-12 col-sm-3 logo"><a href="index-2.html"><img src="images/logo.png" id="logo" class="main img-responsive" alt="Fitness Gym"></a></span>
                    <div class="col-xs-12 col-sm-9 header-right">
                        <div class="header_search_outer">
                            <span class="icon-search-icon"></span>
                            <input type="text" value="" placeholder="Search" class="header_search"/>
                        </div>
                        <!-- Start Navigation -->
                        <nav class="navbar navbar-expand-md navbar-dark navbar-custom">
                            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                                <ul class="navbar-nav">
                                    <li class="nav-item">
                                        <a class="nav-link" href="index.php">Home</a>
                                    </li>                                 
                                    <li class="nav-item">
                                        <a class="nav-link" href="registration form.php">Student Registraion</a>
                                    </li>
                                    <li class="nav-item active">
                                        <a class="nav-link" href="receptionist.php">Record Attendance</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="payments.php">Payments</a>
                                    </li>        
                                </ul>
                            </div>
                        </nav>
                        <!-- End Navigation --> 
                    </div>
                </div>
            </div>
            <!-- End Header Sec --> 
        </header>
        <!-- End Header --> 

        <!-- Start Banner -->
        <div class="banner-outer inner-banner schedule-banner">
            <span class="banner-shadow"></span>
            <div class="container">
                <div class="content" data-aos="fade-down">
                    <h1>PLAYER ATTENDANCE</h1>
                    <div class="breadcrumbs_outer">
                        <div class="container">
                            <ul class="breadcrumbs">
                                <li><a href="index.php">Home</a></li>
                                <li>Reception</li>
                                <li>Record Attendance</li>
                                <li>Player Attendance</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner --> 
        <br><br>
        <form action="insertPlayerAttendance.php" method="post">
            <table>
                <tr>
                    <td><label>Player ID</label></td>
                    <td> :  </td>
                    <td><input type="text" id="pid" name="P_ID" required></td>
                </tr>
                <tr>
                    <td><label>Month</label></td>
                    <td>:  </td>
                    <td>  <select name="month" id="month" name="month" required>
                        <option value=""></option>
                        <option value="January">January</option>
                        <option value="feb">February</option>
                        <option value="mar">March</option>
                        <option value="apr">April</option>
                        <option value="may">May</option>
                        <option value="jun">June</option>
                        <option value="jul">July</option>
                        <option value="aug">August</option>
                        <option value="sep">September</option>
                        <option value="oct">October</option>
                        <option value="nov">November</option>
                        <option value="dec">December</option>
                    </select></td>
                </tr>
                <tr>
                    <td><label>Date</label></td>
                    <td>:  </td>
                    <td><input type="date" id="date" name="date" required></td>
                </tr>
                <tr>
                    <td><label>Attendance</label></td>
            <td>:  </td>
            <td><input type="radio" value="yes" name="Attendancee" id="attendancee">yes <br><input type="radio" value="no" name="Attendancee" id="attendancee">No</td>
                </tr>
            </table>
            <br><br>
            <button onclick="validate()">ADD</button>
        </form>
       
        
        <!-- Scroll to top --> 
        <a href="#" class="scroll-top"><i class="fa fa-chevron-up" aria-hidden="true"></i></a> 

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
        <script src="js/jquery.min.js"></script> 
        <!-- Bootstrap JS --> 
        <script src="assets/bootstrap/js/bootstrap.min.js"></script> 
        <!-- Lightbox JS --> 
        <script src="assets/lightbox/js/lightbox.js"></script> 
        <!-- Owl Carousal JS --> 
        <script src="assets/isotope/js/isotope.min.js"></script> 
        <!-- Owl Carousal JS --> 
        <script src="assets/owl-carousel/js/owl.carousel.min.js"></script>
        <!-- Aos JS --> 
        <script src="assets/aos/aos.js"></script>
        <!-- CounterUp JS --> 
        <script src="assets/counterup/counterup.min.js"></script>
        <script src="assets/counterup/waypoints.min.js"></script>  
        <!-- Custom JS --> 
        <script src="js/custom.js"></script>
        <!-- <script>
            function validate(){
                     var pid=document.getElementById("pid").value;
                     var month=document.getElementById("month").value;
                     var date=document.getElementById("date").value;
                     var atten=document.getElementById("attendancee").value;
                    
                   
 
                     if (pid== null || pid == "" && month == null || month == "" && date == null || date == "") {
                         alert("Inputs can't be Blank");
                     }
                     else if (pid == null || pid == "") {
                         alert("Player can't be Blank");
                     }
                     else if (month == null || month == "") {
                         alert("month Address can't be Blank");
                     }
                     else if(date=="" || date==null){
                         alert("Date can't be Blank...");
                     }
                     else if(atten=="" || atten==null){
                         alert("Attendance can't be Blank...");
                     }
                    
                   
                 }
            
                 
         </script> -->
    </body>

</html>