 <?php
include_once 'db.php';
$sql="SELECT * FROM contact";
$query= mysqli_query($conn,$sql);
if(!$query){
echo "Query does not work." .mysqli_error($conn);die;
}
while($data=mysqli_fetch_array($query)){
echo "Name=".$data['name']."<br>";
echo "Email=".$data['email']."<br>";
echo "Phone=".$data['phone']."<br>";
echo "Message=".$data['msg']."<br><br>";
}
?>