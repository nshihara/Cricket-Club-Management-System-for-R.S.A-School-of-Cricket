<!doctype html>
<html lang="en">
    
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,height=device-height,initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
        <title>Cricket Club</title>
        <!-- Reset CSS -->
        <link href="css/reset.css" rel="stylesheet" type="text/css">
        <!-- Bootstrap -->
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <!-- Font Awesome -->
        <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!-- Iconmoon -->
        <link href="assets/iconmoon/css/iconmoon.css" rel="stylesheet" type="text/css">
        <!-- Lightbox CSS --> 
        <link href="assets/lightbox/css/lightbox.css" rel="stylesheet" type="text/css">
        <!-- Owl Carousel -->
        <link href="assets/owl-carousel/css/owl.carousel.min.css" rel="stylesheet" type="text/css">
        <!-- Animate -->
        <link href="css/animate.css" rel="stylesheet" type="text/css">
		<!-- Aos -->
        <link href="assets/aos/aos.css" rel="stylesheet" type="text/css">
        <!-- Custom Style -->
        <link href="css/custom.css" rel="stylesheet" type="text/css">
        <style>
            body{
                background-image: url("bat.WEBP");
                background-size: cover;
                background-attachment: fixed;
                background-repeat: no-repeat;
            }
            h1{
                font-family: "Times new roman";
                font-weight: bold;
                font-size: 60px;
                color: black;
                font-style: italic;
                text-align: center;
            }
            u{
                color: rgb(24, 23, 23);
                text-decoration-thickness: 3px;
            }
           hr{
            height:3px;
            border-width:0;
            /* color:gray; */
            background-color:gray;
            width:80%;
           
           }
            form{
                margin-top: -30px;
                width: 50%;
                padding-bottom: 1%;
                
            }
       
        
            fieldset{
                
                background: rgba(95, 94, 94, 0.511);
                padding: 5%;
                border: 1px solid rgba(233, 236, 235, 0.511);  
                margin-left: 250px;  
                text-align: center;
                width: 100%; 
                border-radius: 7%;
                
            } 
           
            .lbl{
                font-size: 90%;
                color: rgb(144, 142, 142);
                font-weight: bold;
                font-family: "Segoe UI";
                margin-left: 60px;
               
            }
          
            .rem{
                font-size: 90%;
                margin-left: 35%;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
               
            }
            .inputB{
                background-color: rgba(245, 239, 239, 0.242);
                border-radius: 2%;
                width: 270px;
                border: 1px solid #555;
                margin: 3px;
                padding: 4px;
                display: inline-block;
                /* box-sizing: border-box; */
            }
            button{
                font-weight: bold;
                font-family: "Segoe UI";              
                color: black;
                padding: 1%;
                margin-top: 5%;
                margin-bottom: 5%;
                border-width: 1px;
                border-radius: 5%;
            } 
            #login{
                width: 200px;
                background-color: rgba(232, 168, 38, 0.93);
                font-size: 15px;
                padding: 2%;

            }
            #cancel{
                margin-left: 75%;
                width: 100px;
                border-radius: 40%;
                background-color: rgba(224, 224, 222, 0.342);
            }
            .r{
                text-align: left;

            }
            #imgU{
                width: 100px;
                margin-bottom: 40px;
            }
     
    
           
        </style>
    </head>
    <body>
        <!-- Start Header -->
        <header> 
            <!-- Start Header Sec -->
            <div class="container header-sec">
                <div class="row"> 
                    <span class="col-xs-12 col-sm-3 logo"><a href="index-2.html"><img src="images/logo.png" id="logo" class="main img-responsive" alt="Fitness Gym"></a></span>
                    <div class="col-xs-12 col-sm-9 header-right">
                        <div class="header_search_outer">
                            <span class="icon-search-icon"></span>
                            <input type="text" value="" placeholder="Search" class="header_search"/>
                        </div>
                        <!-- Start Navigation -->
                        <nav class="navbar navbar-expand-md navbar-dark navbar-custom">
                            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                                <ul class="navbar-nav">
                                    <li class="nav-item">
                                        <a class="nav-link" href="index.php">Home</a>
                                    </li>
                                   
                                </ul>
                            </div>
                        </nav>
                        <!-- End Navigation --> 
                    </div>
                </div>
            </div>
            <!-- End Header Sec --> 
        </header>
        <!-- End Header --> 

        <!-- Start Banner -->
        <div class="banner-outer inner-banner schedule-banner">
            <span class="banner-shadow"></span>
            <div class="container">
                <div class="content" data-aos="fade-down">
                    <h1 style="margin-top: -100px;">Login</h1>
                    <div class="breadcrumbs_outer">
                        <div class="container">
                            <ul class="breadcrumbs">
                                <li><a href="index-2.html">Home</a></li>
                                <li>Admin Login</li>
                            </ul>

                            <div class="classSch-outer schedulePage">
                                <div class="container">
                                    <form  action="send1.php" method="POST"> 
                                        <fieldset>
                                           
                                            <img src="u.png" alt="login" id="imgU">
                                          
                                                <div class="lbl">
                                                    <table>
                                                        <tr>
                                                            <td class="r"> <label style="font-weight: bold;">Username</label></td>
                                                            <td>:</td>
                                                            <td><input type="text" class="inputB" name="username" placeholder="Your name.." id="usName"></td>
                                                        </tr>
                                                        <tr>
                                                            <td class="r"><label style="font-weight: bold;"> Password</label></td>
                                                            <td>:</td>
                                                            <td><input type="password" class="inputB" name="password" placeholder="Password.." id="psWord"></td>
                                                        </tr>
                                                      
                            
                                                    </table>
                                                   
                                                    
                                                </div>
                            
                                        
                                            <br>
                                            
                            
                                            <button id="login">Login </button><br>
                                            <hr >
                                            <a href=index.php> <button id="cancel">Cancel</button></a>
                                          
                                            
                                        </fieldset>
                                    </form>
                    
                           
                    
                    
                        
                                <!-- Scroll to top --> 
                                <a href="#" class="scroll-top"><i class="fa fa-chevron-up" aria-hidden="true"></i></a> 
                        
                                <!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
                                <script src="js/jquery.min.js"></script> 
                                <!-- Bootstrap JS --> 
                                <script src="assets/bootstrap/js/bootstrap.min.js"></script> 
                                <!-- Lightbox JS --> 
                                <script src="assets/lightbox/js/lightbox.js"></script> 
                                <!-- Owl Carousal JS --> 
                                <script src="assets/isotope/js/isotope.min.js"></script> 
                                <!-- Owl Carousal JS --> 
                                <script src="assets/owl-carousel/js/owl.carousel.min.js"></script>
                                <!-- Aos JS --> 
                                <script src="assets/aos/aos.js"></script>
                                <!-- CounterUp JS --> 
                                <script src="assets/counterup/counterup.min.js"></script>
                                <script src="assets/counterup/waypoints.min.js"></script>  
                                <!-- Custom JS --> 
                                <script src="js/custom.js"></script>
                        </div>
                        
                    </div>
                </div>
              
            </div>
        </div>
        <!-- End Banner --> 

    </body>

</html>